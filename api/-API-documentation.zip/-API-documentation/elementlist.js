
var ApiGen = ApiGen || {};
ApiGen.elements = [["c","Skimia\\Assets\\AssetsServiceProvider"],["c","Skimia\\Assets\\Console\\Commands\\DumpCollectionsCommand"],["c","Skimia\\Assets\\Console\\Commands\\FlushPipelineCommand"],["c","Skimia\\Assets\\Events\\BeforeMergeCollectionFiles"],["c","Skimia\\Assets\\Manager"],["c","Skimia\\Assets\\Providers\\StolzAssetsServiceProvider"],["c","Skimia\\Assets\\Scanner\\Scanner"],["c","Skimia\\Assets\\Scanner\\ScannerServiceProvider"]];
